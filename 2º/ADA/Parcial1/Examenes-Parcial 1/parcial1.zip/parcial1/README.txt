Ej1 ->  b
Ej2 -> b 
subproblema (h) -> 2
division(b) -> 2
para que O(n^2) se tiene que cumplir que h < b^k
entonces 2 < 2^2 y por lo tanto g(n^2).
K es el exponente de n (n^k)
esta formula esta en la teoria
Ej3 -> c. Esta mal ya que seria en el caso peor de quiksort. El caso mejor da n^2 o n log n en diferentes tipos de casos
Ej4 -> c. Porque el exponente seria 3 * n, pues O(n)
Ej5-> a. Las dos dan n
Ej6-> a. La de quickSort es n y la d no tiene sentido
Ej7-> a
Ej8-> c. Me toco a mi esta, no se si esta bien, si esta mal decidmelo :)
Ej9-> c
Ej10-> a No hagais caso a las anotaciones, es g1 < f <= g2




